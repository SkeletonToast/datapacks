$function parse:score_with_macros {function:"$(function)",prepend:"",append:"",prepend_position:0,append_position:0,score:"$(score)",macros:"$(macros)"}
# $say suwm $(macros)