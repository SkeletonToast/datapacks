# primary stats
scoreboard objectives add EchoLevel dummy
scoreboard objectives add EchoLevelsUnspent dummy
scoreboard objectives add Renown dummy

scoreboard objectives add BaseStrength dummy
scoreboard objectives add BaseDexterity dummy
scoreboard objectives add BaseMind dummy
scoreboard objectives add BaseResolve dummy
scoreboard objectives add BaseVitality dummy
scoreboard objectives add BaseTact dummy
scoreboard objectives add BaseSoul dummy

scoreboard objectives add Strength dummy
scoreboard objectives add Dexterity dummy
scoreboard objectives add Mind dummy
    scoreboard objectives add MindSigned dummy
scoreboard objectives add Tact dummy
scoreboard objectives add Resolve dummy
scoreboard objectives add Vitality dummy
scoreboard objectives add Soul dummy
    scoreboard objectives add SoulSigned dummy

# averaged stats
scoreboard objectives add sse.Physique dummy
scoreboard objectives add sse.Passion dummy
scoreboard objectives add sse.Knowledge dummy

# secondary stats
scoreboard objectives add sse.Charm dummy
scoreboard objectives add sse.Hunger dummy
scoreboard objectives add Initiative dummy
scoreboard objectives add Tenacity dummy
scoreboard objectives add Fortitude dummy

# universal stats
# scoreboard objectives add Potential dummy
# scoreboard objectives add Prowess dummy
    # modify universal stats in echoes:stats/_tick

# attribute stats
scoreboard objectives add str_attributes dummy
scoreboard objectives add dex_attributes dummy
scoreboard objectives add mind_attributes dummy
scoreboard objectives add vit_attributes dummy
scoreboard objectives add tact_attributes dummy
scoreboard objectives add soul_attributes dummy

# stored stats
scoreboard objectives add scale_modifier dummy

scoreboard objectives add generic_attribute dummy

scoreboard objectives add res_max_health dummy
scoreboard objectives add res_armor dummy

scoreboard objectives add smooth_sprint_multiplier dummy
scoreboard objectives add dex_movement_speed dummy
scoreboard objectives add dex_jump_strength dummy
scoreboard objectives add dex_step_height dummy
scoreboard objectives add tact_sneaking_speed dummy

scoreboard objectives add dex_tact_fall_damage_multiplier dummy
scoreboard objectives add dex_tact_safe_fall_distance dummy

scoreboard objectives add str_block_break_speed dummy
scoreboard objectives add str_knockback_resistance dummy

scoreboard objectives add tact_interaction_range dummy
scoreboard objectives add tact_movement_efficiency dummy
scoreboard objectives add tact_water_movement_efficiency dummy
scoreboard objectives add tact_submerged_mining_speed dummy
scoreboard objectives add tact_camera_distance dummy
scoreboard objectives add tact_camera_lock_timer dummy

scoreboard objectives add tact_armor dummy
scoreboard objectives add tact_armor_toughness dummy

scoreboard objectives add soul_burning_time dummy
scoreboard objectives add soul_oxygen_bonus dummy
scoreboard objectives add soul_luck dummy

# movement
scoreboard objectives add StrafeTime dummy
scoreboard objectives add SuperSprintTime dummy
scoreboard objectives add SurgeSprintThreshold dummy