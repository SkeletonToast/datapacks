tag @a[tag=Kindling] remove Kindling
tag @a[tag=near_campfire] remove near_campfire

execute as @e[type=minecraft:interaction,tag=campfire,tag=!soul_campfire] at @s if block ~ ~ ~ soul_campfire run tag @s add soul_campfire
execute as @e[type=minecraft:interaction,tag=soul_campfire] at @s if block ~ ~ ~ campfire run tag @s remove soul_campfire

execute as @a run function echoes:campfires/lanterns/_main

# placing / flint and steel
# scoreboard players set @a[scores={used_flint_and_steel=1..}] placed_campfire 1
scoreboard players set @a[scores={placed_soul_campfire=1..}] placed_campfire 1
execute as @a[scores={placed_campfire=1}] at @s anchored eyes positioned ^ ^ ^0.25 run function \
    raycast:block_specific {"block":"#minecraft:campfires","particle":"execute if entity @s","increment_distance":"0.25","max_lifetime":"30","run_on_success":"execute align xyz positioned ~0.5 ~0.15 ~0.5 run function echoes:campfires/place",solid_block_collision:false}
    # campfires/place now sets your placed_campfire score to 0, so if you still have a score of 1 after the initial raycast, it means it didn't hit the campfire
        # all the functions below only trigger if the previous functions all failed
execute as @a[scores={placed_campfire=1}] at @s anchored eyes positioned ^ ^1 ^0.25 run function \
    raycast:block_specific {"block":"#minecraft:campfires","particle":"execute if entity @s","increment_distance":"0.25","max_lifetime":"30","run_on_success":"execute align xyz positioned ~0.5 ~0.15 ~0.5 run function echoes:campfires/place",solid_block_collision:false}
execute as @a[scores={placed_campfire=1}] at @s anchored eyes positioned ^1 ^ ^0.25 run function \
    raycast:block_specific {"block":"#minecraft:campfires","particle":"execute if entity @s","increment_distance":"0.25","max_lifetime":"30","run_on_success":"execute align xyz positioned ~0.5 ~0.15 ~0.5 run function echoes:campfires/place",solid_block_collision:false}
execute as @a[scores={placed_campfire=1}] at @s anchored eyes positioned ^ ^-1 ^0.25 run function \
    raycast:block_specific {"block":"#minecraft:campfires","particle":"execute if entity @s","increment_distance":"0.25","max_lifetime":"30","run_on_success":"execute align xyz positioned ~0.5 ~0.15 ~0.5 run function echoes:campfires/place",solid_block_collision:false}
execute as @a[scores={placed_campfire=1}] at @s anchored eyes positioned ^-1 ^ ^0.25 run function \
    raycast:block_specific {"block":"#minecraft:campfires","particle":"execute if entity @s","increment_distance":"0.25","max_lifetime":"30","run_on_success":"execute align xyz positioned ~0.5 ~0.15 ~0.5 run function echoes:campfires/place",solid_block_collision:false}

# ember sprites
execute at @e[type=marker,tag=EmberSprite] run particle trial_spawner_detection ~ ~ ~ 0.1 0.1 0.1 0 1 normal @a
execute at @e[type=marker,tag=EmberSprite] run particle small_flame ~ ~ ~ 0.1 0.1 0.1 0 1 normal @a
execute at @e[type=marker,tag=EmberSprite,scores={Age=..-30}] run particle end_rod ~ ~0.1 ~ 0.01 0.01 0.01 0 1 normal @a
execute at @e[type=marker,tag=EmberSprite,scores={Age=-2..}] run particle large_smoke ~ ~ ~ 0.1 0.1 0.1 0 10 normal @a
execute at @e[type=marker,tag=EmberSprite,scores={Age=-1..}] run fill ~ ~ ~ ~ ~ ~ air replace light[level=8]

# near campfires
execute as @a at @s as @e[type=interaction,tag=campfire,distance=..10] at @s positioned ~-10 ~-1 ~-10 run tag @a[dx=20,dy=11,dz=20] add near_campfire_10
execute as @a[tag=near_campfire_10] at @s as @e[type=interaction,tag=campfire,distance=..5] at @s positioned ~-5 ~-1 ~-5 run tag @a[dx=10,dy=6,dz=10] add near_campfire_5
tag @a[tag=near_campfire_10] add near_campfire


# particles
execute at @e[type=minecraft:interaction,tag=campfire,tag=!soul_campfire] run particle trial_spawner_detection ~ ~ ~ 0.2 0.2 0.2 0 1 normal @a
execute at @e[type=minecraft:interaction,tag=soul_campfire] run particle trial_spawner_detection_ominous ~ ~ ~ 0.2 0.2 0.2 0 1 normal @a

execute at @e[type=minecraft:interaction,tag=campfire,tag=!soul_campfire] as @a[distance=..10] unless entity @s[predicate=ss_lib:is/hiding] if predicate ss_lib:random_10_percent at @s anchored eyes run particle trial_spawner_detection ^ ^ ^ 0.2 0.2 0.2 0 1 normal @a[distance=0.1..]
execute at @e[type=minecraft:interaction,tag=soul_campfire] as @a[distance=..10] unless entity @s[predicate=ss_lib:is/hiding] if predicate ss_lib:random_10_percent at @s anchored eyes run particle trial_spawner_detection_ominous ^ ^ ^ 0.2 0.2 0.2 0 1 normal @a[distance=0.1..]
    # execute at @e[type=minecraft:interaction,tag=soul_campfire] run particle ominous_spawning ~ ~0.2 ~ 0 0 0 0.5 1 normal @a

# kindling / breaking
execute as @e[type=minecraft:interaction,tag=campfire] at @s if data entity @s interaction on target run function echoes:campfires/kindle
execute as @e[type=minecraft:interaction,tag=campfire] at @s if data entity @s attack on attacker run function echoes:campfires/break

# break particles
execute as @e[type=minecraft:interaction,tag=campfire,tag=!soul_campfire] at @s unless block ~ ~ ~ campfire[lit=true] align y run function echoes:campfires/particles_campfire
execute as @e[type=minecraft:interaction,tag=soul_campfire] at @s unless block ~ ~ ~ soul_campfire[lit=true] align y run function echoes:campfires/particles_soul_campfire
execute as @e[type=minecraft:interaction,tag=campfire] at @s unless block ~ ~ ~ #minecraft:campfires[lit=true] run kill @s

# data removal
execute as @e[type=minecraft:interaction,tag=campfire] if data entity @s interaction run data remove entity @s interaction
execute as @e[type=minecraft:interaction,tag=campfire] if data entity @s attack run data remove entity @s attack

# erdefret - probably also make some sort of incense for this!!
# execute if entity @a[scores={Dimension=4}] as @e[type=minecraft:interaction,tag=campfire] at @s if dimension eochrin:erdefret run function echoes:campfires/erdefret
# execute if entity @a[scores={Dimension=4}] as @e[type=marker,tag=EmberSprite] at @s if dimension eochrin:erdefret run effect give @e[type=#ss_lib:hostile,distance=..5] slowness 1 0 true
    execute as @a[scores={Dimension=4}] at @s anchored eyes facing entity @n[type=minecraft:interaction,tag=campfire,distance=5..50] feet run particle flame ^ ^ ^3 0 0 0 0 1 normal @s

# overheal enabling - make some sort of incense for this
execute at @e[type=minecraft:interaction,tag=campfire] as @a[distance=..10] run scoreboard players operation @s overheal_limit = @s BaseMaxHealth

# range display
execute as @e[type=minecraft:interaction,tag=campfire,scores={campfire_display_range=1..}] at @s run function echoes:campfires/range_display

# score resets
scoreboard players remove @e[type=minecraft:interaction,tag=campfire,scores={campfire_display_range=0..}] campfire_display_range 1
    # scoreboard players set @a[scores={used_flint_and_steel=1..}] used_flint_and_steel 0
scoreboard players set @a[scores={placed_campfire=1..}] placed_campfire 0
scoreboard players set @a[scores={placed_soul_campfire=1..}] placed_soul_campfire 0

# campfire respawning
# execute as @r[scores={campfire_spawn=1,TimeSinceDeath=1}] run function echoes:campfires/respawn