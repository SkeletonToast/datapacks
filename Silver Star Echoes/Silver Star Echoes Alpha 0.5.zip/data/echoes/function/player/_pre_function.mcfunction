execute as @a run function echoes:player/difficulty

scoreboard players set @a encumbrance 0
scoreboard players set @a encumbrance_hard 0
scoreboard players set @a encumbrance_reduction 0
scoreboard players set @a encumbrance_armor 0
scoreboard players set @a encumbrance_items 0

scoreboard players set @a xp_cap 0

# proficiency
scoreboard players set @a proficiency_str 0
scoreboard players set @a proficiency_dex 0
scoreboard players set @a proficiency_tact 0
scoreboard players set @a proficiency_soul 0
scoreboard players set @a proficiency_mind 0

# aegis timer
# scoreboard players set @a aegis_timer_max 100

# temperature
scoreboard players set @a temp_default 65
execute as @a run scoreboard players operation @s heat_resistance = @s Vitality
    execute as @a run scoreboard players operation @s heat_resistance /= #const.2 value
execute as @a run scoreboard players operation @s cold_resistance = @s Vitality
    execute as @a run scoreboard players operation @s cold_resistance /= #const.2 value

tag @a add TemperatureEligible
tag @a[scores={sse.difficulty=..2}] remove TemperatureEligible
tag @a[scores={Dimension=5}] remove TemperatureEligible
tag @a[gamemode=!survival,gamemode=!adventure] remove TemperatureEligible

scoreboard players set @a[scores={OnGround=1}] boost_visual_effects 0
execute as @a run attribute @s minecraft:gravity modifier remove mind.elytra_gravity
execute as @a run attribute @s minecraft:movement_speed modifier remove elytra_visual_speed

tag @a[scores={sse.difficulty=1}] remove InCombat
function echoes:player/combat/_main
tag @a[scores={sse.difficulty=1}] remove InCombat
scoreboard players set @a[scores={sse.difficulty=1}] in_combat 0

# these are here so that combat tags can be effectively removed before the titles show up
execute as @a[scores={in_combat=1..},tag=!InCombat] run function echoes:player/combat/enter/message
tag @a[scores={in_combat=1..}] add InCombat
tag @a[scores={in_combat=-1}] add InCombat
execute as @a[scores={in_combat=0},tag=InCombat] run function echoes:player/combat/exit_message
execute as @a[scores={in_combat=0},tag=InCombat] run function echoes:player/combat/techniques/disable
tag @a[scores={in_combat=0}] remove InCombat

# homesteader compatibility
scoreboard players set @a[tag=InCombat] homestead.day_title_eligible 0

# scoreboard players set $strength player_motion.api.launch 10000