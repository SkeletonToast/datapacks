function sse.dev:set_stats/set_stats {"st":40,"dx":40,"rs":60,"vt":20,"md":15,"tc":30,"sl":60}

tellraw @s [{"text":"❖ Loaded stats of Tanwyn, once of the Entertainers.","color":"gray"}]