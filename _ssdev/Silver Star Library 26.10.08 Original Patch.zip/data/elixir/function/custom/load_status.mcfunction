$scoreboard objectives add $(source).$(status).duration dummy
$scoreboard objectives add $(source).$(status).amplifier dummy
$scoreboard objectives add $(source).$(status).stored_amplifier dummy
# $scoreboard objectives add $(source).$(status).runtime dummy
# $scoreboard objectives add $(source).$(status).stacks dummy