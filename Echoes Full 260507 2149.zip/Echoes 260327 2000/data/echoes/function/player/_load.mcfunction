scoreboard objectives add in_combat dummy

scoreboard objectives add Day dummy

scoreboard objectives add GameTime dummy

scoreboard objectives add EchoDifficulty dummy

scoreboard objectives add xp_level level
scoreboard objectives add xp_stored dummy

scoreboard objectives add fear dummy
scoreboard objectives add fear_eligible dummy

scoreboard objectives add used_glow_berries minecraft.used:minecraft.glow_berries

gamerule naturalRegeneration false

# aegis
    scoreboard objectives add aegis_timer dummy
    scoreboard objectives add aegis_timer_max dummy
    scoreboard objectives add aegis_timer_reduction dummy
    scoreboard objectives add used_golden_apple minecraft.used:minecraft.golden_apple
    scoreboard objectives add used_enchanted_golden_apple minecraft.used:minecraft.enchanted_golden_apple
    scoreboard objectives add aegis_amplifier_max dummy
    scoreboard objectives add aegis_amplifier dummy

    scoreboard objectives add aegis_base_color trigger

    scoreboard objectives add killed_mob minecraft.custom:mob_kills
    scoreboard objectives add killed_player minecraft.custom:player_kills

    scoreboard objectives add ichor_damage dummy

# healing items
    scoreboard objectives add used_honey_bottle minecraft.used:minecraft.honey_bottle
    scoreboard objectives add used_golden_carrot minecraft.used:minecraft.golden_carrot

    scoreboard objectives add overheal_limit dummy

# encumbrance
    scoreboard objectives add encumbrance dummy
    scoreboard objectives add encumbrance_hard dummy
    scoreboard objectives add encumbrance_unadjusted dummy
    scoreboard objectives add encumbrance_reduction dummy
    scoreboard objectives add encumbrance_half dummy
    scoreboard objectives add encumbrance_items dummy
    scoreboard objectives add encumbrance_armor dummy

# proficiency
    scoreboard objectives add proficiency dummy
    scoreboard objectives add proficiency_temp dummy
    scoreboard objectives add proficiency_str dummy
    scoreboard objectives add proficiency_dex dummy
    scoreboard objectives add proficiency_tact dummy
    scoreboard objectives add proficiency_soul dummy
    scoreboard objectives add proficiency_mind dummy
    scoreboard objectives add prof_str_unadj dummy
    scoreboard objectives add prof_dex_unadj dummy
    scoreboard objectives add prof_tact_unadj dummy
    scoreboard objectives add prof_soul_unadj dummy
    scoreboard objectives add prof_mind_unadj dummy
    
    scoreboard objectives add proficiency_recursion dummy
    scoreboard objectives add proficiency_inc_sum dummy
    scoreboard objectives add minprof dummy
    scoreboard objectives add prof dummy
    scoreboard objectives add statmax dummy
    scoreboard objectives add scale dummy
    scoreboard objectives add truth dummy
    scoreboard objectives add mintruth dummy
    scoreboard objectives add lies dummy
    scoreboard objectives add maybe dummy

# elytra scaling stuff
    scoreboard objectives add elytra_boost_cooldown dummy
    scoreboard objectives add flight_level dummy
    scoreboard objectives add used_firework_rocket minecraft.used:firework_rocket
    scoreboard objectives add slipstream dummy
    scoreboard objectives add boosts_in_inventory dummy
        #amt of boosts in inventory
    scoreboard objectives add boosts_stored dummy
        #stored boosts
    # scoreboard objectives add flight_level dummy
        #maximum allotted amt of boosts
    scoreboard objectives add boost_visual_effects dummy
        #boost visual effect timer

    scoreboard objectives add air_brake_time dummy

# temperature
    scoreboard objectives add display_temp dummy

    scoreboard objectives add temp dummy
    scoreboard objectives add temp_default dummy
    scoreboard objectives add temp_modifier dummy
    scoreboard objectives add ambient_temp dummy

    scoreboard objectives add cold_resistance dummy
    scoreboard objectives add heat_resistance dummy

    scoreboard objectives add temp_difference dummy
        # scoreboard objectives remove body_temp
        # scoreboard objectives remove body_temp_modifier

    scoreboard objectives add drink_water minecraft.used:minecraft.potion