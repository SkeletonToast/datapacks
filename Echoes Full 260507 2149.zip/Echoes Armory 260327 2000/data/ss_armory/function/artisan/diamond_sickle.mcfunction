item modify entity @s weapon.mainhand [{"function":"minecraft:set_attributes","modifiers":[ \
{"id":"mainhand_attack_damage","attribute":"minecraft:attack_damage","amount":6,"operation":"add_value","slot":"mainhand"}, \
{"id":"mainhand_attack_speed","attribute":"minecraft:attack_speed","amount":-2.0,"operation":"add_value","slot":"mainhand"}],"replace":true}]
function ss_armory:artisan/sickle
item modify entity @s weapon.mainhand [{"function":"minecraft:set_lore","lore":[{"text":" 7 Attack Damage","italic":false,"color":"dark_green"}],"mode":"append"}]
item modify entity @s weapon.mainhand [{"function":"minecraft:set_lore","lore":[{"text":" 2.0 Attack Speed","italic":false,"color":"dark_green"}],"mode":"append"}]

item modify entity @s weapon.mainhand [{"function":"minecraft:set_components","components":{"minecraft:item_name":"Diamond Sickle"}}]