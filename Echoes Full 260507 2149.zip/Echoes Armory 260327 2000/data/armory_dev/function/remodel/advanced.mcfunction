item modify entity @s weapon.mainhand [{"function":"minecraft:set_custom_model_data","strings":{"values":['advanced'],"mode":"replace_all"}}]
