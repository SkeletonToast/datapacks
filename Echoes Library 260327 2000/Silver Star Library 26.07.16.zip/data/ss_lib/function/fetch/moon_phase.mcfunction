execute store result score $moon MoonPhase run time query minecraft:moon
scoreboard players set $moon generic_a 24000
scoreboard players operation $moon MoonPhase /= $moon generic_a
scoreboard players add $moon MoonPhase 1